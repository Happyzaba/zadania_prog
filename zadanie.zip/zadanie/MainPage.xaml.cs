﻿#if WINDOWS
using Windows.Storage;
using Windows.Storage.Pickers;
using WinRT.Interop;
#endif
namespace EgzaminMauiApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void EncryptButton_Clicked(object sender, EventArgs e)
        {
            string text = PlainTextEditor.Text;
            string keyText = KeyEntry.Text;

            int key;
            if (!int.TryParse(keyText.Trim(), out key))
            {  
                key = 0;
            }

          //  string encrypted = CaesarCipher.Encrypt(text, key);
            //CipherTextLabel.Text = encrypted;
        }
        private async void SaveButton_Clicked(object sender, EventArgs e)
        {
            string content = CipherTextLabel.Text;
            if (string.IsNullOrEmpty(content))
            {
                await DisplayAlert("Uwaga", "Brak zaszyfrowanego tekstu do zapisania.", "OK");
                return;
            }
#if WINDOWS
        async void SaveFileWindowsAsync(object sender, EventArgs e)
        {
            var picker = new FileSavePicker();
            picker.SuggestedStartLocation = PickerLocationId.DocumentsLibrary;
            picker.FileTypeChoices.Add("Text file", new List<string> { ".txt" });
            picker.SuggestedFileName = "Tekst";

            // Powiązanie z oknem MAUI
            var window = Application.Current.Windows.First().Handler.PlatformView as Microsoft.UI.Xaml.Window;
            IntPtr hWnd = WindowNative.GetWindowHandle(window);
            InitializeWithWindow.Initialize(picker, hWnd);

            StorageFile file = await picker.PickSaveFileAsync();
            if (file != null)
            {    
                File.WriteAllText(file.Path, "TO CO MAMY ZAPISAĆ");
            }
        }
#else
            async void SaveFileWindowsAsync(object sender, EventArgs e)
            {

            }
#endif
        }
    }
}
